import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.optimizers import Adam, SGD
import numpy as np
import matplotlib.pyplot as plt

# Load pre-trained model
model = load_model('emotion_model.h5')

# Load your dataset
X_test = np.load('X_test.npy')
y_test = np.load('y_test.npy')

# Normalize data if necessary
X_test = X_test / 255.0

def evaluate_model_with_optimizer(model, optimizer, X_test, y_test):
    model.compile(optimizer=optimizer, 
                  loss='sparse_categorical_crossentropy', 
                  metrics=['accuracy'])
    loss, accuracy = model.evaluate(X_test, y_test, verbose=0)
    return loss, accuracy

# Make a copy of the model for each optimizer to avoid interference
model_adam = tf.keras.models.clone_model(model)
model_adam.set_weights(model.get_weights())

model_sgd = tf.keras.models.clone_model(model)
model_sgd.set_weights(model.get_weights())

# Evaluate with Adam optimizer
adam_optimizer = Adam()
loss_adam, accuracy_adam = evaluate_model_with_optimizer(model_adam, adam_optimizer, X_test, y_test)

# Evaluate with SGD optimizer
sgd_optimizer = SGD()
loss_sgd, accuracy_sgd = evaluate_model_with_optimizer(model_sgd, sgd_optimizer, X_test, y_test)

# Print results
print(f"Adam Optimizer - Loss: {loss_adam}, Accuracy: {accuracy_adam}")
print(f"SGD Optimizer - Loss: {loss_sgd}, Accuracy: {accuracy_sgd}")

# Plotting the results
optimizers = ['Adam', 'SGD']
losses = [loss_adam, loss_sgd]
accuracies = [accuracy_adam, accuracy_sgd]

plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.bar(optimizers, losses, color=['blue', 'orange'])
plt.title('Loss Comparison')
plt.ylabel('Loss')

plt.subplot(1, 2, 2)
plt.bar(optimizers, accuracies, color=['blue', 'orange'])
plt.title('Accuracy Comparison')
plt.ylabel('Accuracy')

plt.tight_layout()
plt.show()
